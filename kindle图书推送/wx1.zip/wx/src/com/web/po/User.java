package com.web.po;

public class User {

	private String openid;
	private String email;
	private String activedate;
	private String timelengt;
	private String isactived;
	public String getOpenid() {
		return openid;
	}
	public void setOpenid(String openid) {
		this.openid = openid;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getActivedate() {
		return activedate;
	}
	public void setActivedate(String activedate) {
		this.activedate = activedate;
	}
	public String getTimelengt() {
		return timelengt;
	}
	public void setTimelengt(String timelengt) {
		this.timelengt = timelengt;
	}
	public String getIsactived() {
		return isactived;
	}
	public void setIsactived(String isactived) {
		this.isactived = isactived;
	}
	
	
}
