package com.web.po;

public class BookType {

	private Long booktype_id;
	private String booktype_name;
	private String booktype_img;
	public Long getBooktype_id() {
		return booktype_id;
	}
	public void setBooktype_id(Long booktype_id) {
		this.booktype_id = booktype_id;
	}
	public String getBooktype_name() {
		return booktype_name;
	}
	public void setBooktype_name(String booktype_name) {
		this.booktype_name = booktype_name;
	}
	public String getBooktype_img() {
		return booktype_img;
	}
	public void setBooktype_img(String booktype_img) {
		this.booktype_img = booktype_img;
	}
	
	
}
