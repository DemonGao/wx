package com.admin.Po;

public class ActiveCode {

	private long activecode_id;
	private String activecode_time;
	private String activecode;
	private String isused;
	public long getActivecode_id() {
		return activecode_id;
	}
	public void setActivecode_id(long activecode_id) {
		this.activecode_id = activecode_id;
	}
	public String getActivecode_time() {
		return activecode_time;
	}
	public void setActivecode_time(String activecode_time) {
		this.activecode_time = activecode_time;
	}
	public String getActivecode() {
		return activecode;
	}
	public void setActivecode(String activecode) {
		this.activecode = activecode;
	}
	public String getIsused() {
		return isused;
	}
	public void setIsused(String isused) {
		this.isused = isused;
	}
}
