$(function(){
	ajaxBook({serchTag:'sort',currentPage:1},'booksort','booksort');
});
