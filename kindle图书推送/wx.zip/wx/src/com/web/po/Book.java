package com.web.po;

public class Book {
	private long book_id;
	private String book_name;
	private String book_info;
	private String book_img;
	private String book_url;
	private String book_uptime;
	private String book_type;
	private int book_downnum;
	public long getBook_id() {
		return book_id;
	}
	public void setBook_id(long book_id) {
		this.book_id = book_id;
	}
	public String getBook_name() {
		return book_name;
	}
	public void setBook_name(String book_name) {
		this.book_name = book_name;
	}
	public String getBook_info() {
		return book_info;
	}
	public void setBook_info(String book_info) {
		this.book_info = book_info;
	}
	public String getBook_img() {
		return book_img;
	}
	public void setBook_img(String book_img) {
		this.book_img = book_img;
	}
	public String getBook_url() {
		return book_url;
	}
	public void setBook_url(String book_url) {
		this.book_url = book_url;
	}
	public String getBook_uptime() {
		return book_uptime;
	}
	public void setBook_uptime(String book_uptime) {
		this.book_uptime = book_uptime;
	}
	public int getBook_downnum() {
		return book_downnum;
	}
	public void setBook_downnum(int book_downnum) {
		this.book_downnum = book_downnum;
	}
	public String getBook_type() {
		return book_type;
	}
	public void setBook_type(String book_type) {
		this.book_type = book_type;
	}
	
	
}
