package com.admin.Po;

public class User {

	private String openid;
	private String email;
	private String activedate;
	private String timelength;
	private String isactived;
	public String getOpenid() {
		return openid;
	}
	public void setOpenid(String openid) {
		this.openid = openid;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getActivedate() {
		return activedate;
	}
	public void setActivedate(String activedate) {
		this.activedate = activedate;
	}
	public String getTimelength() {
		return timelength;
	}
	public void setTimelength(String timelength) {
		this.timelength = timelength;
	}
	public String getIsactived() {
		return isactived;
	}
	public void setIsactived(String isactived) {
		this.isactived = isactived;
	}
	
	
}
