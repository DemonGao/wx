package com.wx.trans;

public class Parts {
	private String part;
	private String[] means;
	public String getPart() {
		return part;
	}
	public void setPart(String part) {
		this.part = part;
	}
	public String[] getMeans() {
		return means;
	}
	public void setMeans(String[] means) {
		this.means = means;
	}
}
